export interface CanvasPosition {
  x: number;
  y: number;
  width: number;
  height: number;
}

interface LevelLayout {
  positions: Record<string, CanvasPosition>;
  connections: [string, string][];
}

// ── Curated root layout ────────────────────────────────────────────────────
const ROOT_LAYOUT: LevelLayout = {
  positions: {
    minecon:   { x: 380,  y: 260,  width: 500, height: 260 },
    synset:    { x: 1140, y: 180,  width: 480, height: 280 },
    personal:  { x: 1880, y: 300,  width: 440, height: 240 },
    academico: { x: 420,  y: 820,  width: 460, height: 240 },
    identidad: { x: 1100, y: 860,  width: 440, height: 220 },
    actividad: { x: 1780, y: 840,  width: 420, height: 220 },
  },
  connections: [
    ['academico', 'minecon'],
    ['academico', 'synset'],
    ['minecon',   'synset'],
    ['synset',    'personal'],
    ['minecon',   'actividad'],
    ['synset',    'actividad'],
    ['identidad', 'minecon'],
    ['identidad', 'synset'],
  ],
};

// ── Per-node curated layouts ─────────────────────────────────────────────────
const CURATED: Record<string, LevelLayout> = {
  minecon: {
    positions: {
      stamping:      { x: 260,  y: 200,  width: 500, height: 260 },
      analyticsdb:   { x: 1040, y: 150,  width: 460, height: 240 },
      agenda:        { x: 1740, y: 240,  width: 440, height: 240 },
      checklist:     { x: 380,  y: 760,  width: 440, height: 240 },
      'minecon-web': { x: 1120, y: 800,  width: 440, height: 220 },
    },
    connections: [
      ['stamping',    'analyticsdb'],
      ['agenda',      'checklist'],
      ['stamping',    'checklist'],
      ['analyticsdb', 'minecon-web'],
    ],
  },
  synset: {
    positions: {
      tucolmado:      { x: 260,  y: 200,  width: 500, height: 280 },
      fleetcore:      { x: 1060, y: 150,  width: 480, height: 280 },
      nexusbilling:   { x: 1800, y: 240,  width: 440, height: 260 },
      'synset-infra': { x: 900,  y: 800,  width: 460, height: 240 },
    },
    connections: [
      ['tucolmado',    'fleetcore'],
      ['fleetcore',    'nexusbilling'],
      ['nexusbilling', 'synset-infra'],
      ['tucolmado',    'synset-infra'],
    ],
  },
  personal: {
    positions: {
      lintab:      { x: 280,  y: 300, width: 480, height: 260 },
      formalizate: { x: 1080, y: 250, width: 480, height: 280 },
      tecto:       { x: 1760, y: 320, width: 420, height: 240 },
    },
    connections: [
      ['lintab',     'formalizate'],
      ['formalizate','tecto'],
    ],
  },
  academico: {
    positions: {
      hermes:         { x: 260,  y: 200, width: 480, height: 240 },
      itlanetworking: { x: 1060, y: 160, width: 460, height: 240 },
      appcenar:       { x: 1760, y: 260, width: 420, height: 240 },
      montecarlo:     { x: 800,  y: 760, width: 460, height: 240 },
    },
    connections: [
      ['hermes',         'itlanetworking'],
      ['itlanetworking', 'appcenar'],
      ['hermes',         'montecarlo'],
    ],
  },
  identidad: {
    positions: {
      filosofia: { x: 440,  y: 320, width: 520, height: 300 },
      hoy:       { x: 1260, y: 300, width: 500, height: 280 },
    },
    connections: [['filosofia', 'hoy']],
  },
  actividad: {
    positions: {
      'github-evidencia': { x: 680, y: 360, width: 540, height: 300 },
    },
    connections: [],
  },
  // Section interiors (leaf-level canvases)
  stamping: {
    positions: {
      'stamping-problema':     { x: 280,  y: 280, width: 480, height: 260 },
      'stamping-arquitectura': { x: 1060, y: 230, width: 480, height: 280 },
      'stamping-resultado':    { x: 1780, y: 300, width: 440, height: 260 },
    },
    connections: [
      ['stamping-problema',     'stamping-arquitectura'],
      ['stamping-arquitectura', 'stamping-resultado'],
    ],
  },
  analyticsdb: {
    positions: {
      'analytics-problema':     { x: 480,  y: 300, width: 500, height: 280 },
      'analytics-arquitectura': { x: 1260, y: 280, width: 480, height: 280 },
    },
    connections: [['analytics-problema', 'analytics-arquitectura']],
  },
  tucolmado: {
    positions: {
      'tucolmado-problema':     { x: 480,  y: 300, width: 500, height: 280 },
      'tucolmado-arquitectura': { x: 1260, y: 280, width: 480, height: 280 },
    },
    connections: [['tucolmado-problema', 'tucolmado-arquitectura']],
  },
  fleetcore: {
    positions: {
      'fleetcore-problema': { x: 480,  y: 300, width: 500, height: 280 },
      'fleetcore-negocio':  { x: 1260, y: 280, width: 480, height: 280 },
    },
    connections: [['fleetcore-problema', 'fleetcore-negocio']],
  },
};

// ── Auto-layout for any level not in CURATED ─────────────────────────────────
function computeAutoLayout(nodeIds: string[]): LevelLayout {
  const N = nodeIds.length;
  const W = 460, H = 240;
  const GAP_X = 200, GAP_Y = 180;
  const COLS = N === 1 ? 1 : N <= 2 ? 2 : N <= 4 ? 2 : 3;
  const startX = 300, startY = 260;

  const positions: Record<string, CanvasPosition> = {};
  nodeIds.forEach((id, i) => {
    const col = i % COLS;
    const row = Math.floor(i / COLS);
    const rowCount = Math.min(N - row * COLS, COLS);
    const rowOffset = ((COLS - rowCount) * (W + GAP_X)) / 2;
    positions[id] = {
      x: startX + col * (W + GAP_X) + rowOffset,
      y: startY + row * (H + GAP_Y) + (col % 2 === 1 ? 30 : 0),
      width: W,
      height: H,
    };
  });

  const connections: [string, string][] = nodeIds
    .slice(1)
    .map((id, i) => [nodeIds[i], id] as [string, string]);

  return { positions, connections };
}

// ── Public API ────────────────────────────────────────────────────────────────
export function getLevelLayout(levelId: string, childIds: string[]): LevelLayout {
  if (levelId === 'root') return ROOT_LAYOUT;
  return CURATED[levelId] ?? computeAutoLayout(childIds);
}

// Legacy exports used by old components — kept for compat
export const CANVAS_LAYOUT = ROOT_LAYOUT.positions;
export const CANVAS_CONNECTIONS = ROOT_LAYOUT.connections;
