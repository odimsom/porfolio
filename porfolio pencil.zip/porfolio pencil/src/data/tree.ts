export type NodeType = 'root' | 'chapter' | 'section' | 'leaf';
export type NodeScope =
  | 'IDENTIDAD'
  | 'EXPERIENCIA'
  | 'CO-FOUNDER'
  | 'PROYECTO'
  | 'EVIDENCIA'
  | 'FILOSOFÍA'
  | 'ACADÉMICO'
  | 'CONTACTO';

export interface LeafBlock {
  kind: 'context' | 'built' | 'decision' | 'outcome' | 'stack' | 'quote';
  label: string;
  body: string;
}

export interface TreeNode {
  id: string;
  type: NodeType;
  scope?: NodeScope;
  eyebrow?: string;
  title: string;
  description?: string;
  children?: TreeNode[];
  blocks?: LeafBlock[];
}

export const TREE: TreeNode = {
  id: 'root',
  type: 'root',
  title: 'Francisco Castro',
  description: 'Software Developer · Enterprise Systems & Integrations',
  children: [

    // ── MINECON ────────────────────────────────────────────────────────────
    {
      id: 'minecon',
      type: 'chapter',
      scope: 'EXPERIENCIA',
      eyebrow: '2022 — Presente',
      title: 'MINECON S.A.',
      description:
        'El entorno donde pasé de aprender patrones en libros a aplicarlos en sistemas que operan en producción diaria. Cinco productos construidos, cada uno con un problema de negocio diferente.',
      children: [
        {
          id: 'stamping',
          type: 'section',
          scope: 'PROYECTO',
          eyebrow: 'Scania · MINECON',
          title: 'StampingTaller',
          description:
            'Sistema integral de gestión de taller para Scania/MINECON. Órdenes de trabajo, mecánicos, tiempo real y sincronización con Business Central.',
          children: [
            {
              id: 'stamping-problema',
              type: 'leaf',
              title: 'El problema',
              blocks: [
                {
                  kind: 'context',
                  label: 'Contexto operativo',
                  body: 'El taller de Scania operaba con procesos manuales y sin visibilidad centralizada sobre el estado de las órdenes de trabajo. La información vivía dispersa entre sistemas, hojas de cálculo y comunicación verbal. Reconciliar lo que había pasado en el taller con lo que estaba registrado en Business Central tomaba horas al día.',
                },
                {
                  kind: 'outcome',
                  label: 'La consecuencia',
                  body: 'La falta de trazabilidad en tiempo real generaba errores de facturación, cuellos de botella en la asignación de tareas y pérdida de visibilidad gerencial sobre la operación. El ERP tenía la información, pero siempre tarde y manual.',
                },
              ],
            },
            {
              id: 'stamping-arquitectura',
              type: 'leaf',
              title: 'La arquitectura',
              blocks: [
                {
                  kind: 'decision',
                  label: 'Multi-tenant con SQL Server dinámico',
                  body: 'El sistema debía servir a múltiples empresas del grupo MINECON con bases de datos separadas por tenant. Implementé resolución dinámica de cadenas de conexión en runtime — cada request lleva su contexto de empresa y el middleware resuelve cuál base de datos usar. Esto mantiene el aislamiento de datos sin duplicar la infraestructura de código.',
                },
                {
                  kind: 'decision',
                  label: 'Integración SOAP con Business Central',
                  body: 'BC expone sus servicios vía SOAP para ciertos módulos críticos. Construí una capa de integración tipada en .NET que abstrae la complejidad del protocolo — el resto de la aplicación no sabe que está hablando con un servicio SOAP de los años 2000.',
                },
                {
                  kind: 'built',
                  label: 'CI/CD en IIS con GitHub Actions',
                  body: 'El pipeline despliega automáticamente a IIS en los servidores de MINECON. Cada push a main pasa por build, test y deploy — sin intervención manual. En un entorno corporativo con IIS esto no es trivial; requirió configurar self-hosted runners y manejo de credenciales con los equipos de infraestructura.',
                },
                {
                  kind: 'stack',
                  label: 'Stack',
                  body: 'Angular 18+ · .NET 8 · SOAP (Business Central) · SQL Server (multi-tenant dinámico) · SignalR · GitHub Actions · IIS',
                },
              ],
            },
            {
              id: 'stamping-resultado',
              type: 'leaf',
              title: 'Lo que aprendí',
              blocks: [
                {
                  kind: 'outcome',
                  label: 'El aprendizaje de la integración',
                  body: 'Integrar con un ERP empresarial como BC enseña una lección fundamental: el ERP no es la fuente de verdad de todo. Hay datos que pertenecen al sistema local y datos que pertenecen al ERP — confundirlos genera sistemas frágiles que se rompen cuando el ERP cambia.',
                },
                {
                  kind: 'context',
                  label: 'El costo del multi-tenancy',
                  body: 'Implementar multi-tenancy desde el inicio cuando el cliente lo pide parece simple. La complejidad aparece en testing, en migrations, en logging contextual y en debugging — todo tiene que saber a qué tenant pertenece.',
                },
              ],
            },
          ],
        },

        {
          id: 'analyticsdb',
          type: 'section',
          scope: 'PROYECTO',
          eyebrow: 'Arquitectura de datos',
          title: 'AnalyticsDB',
          description:
            'Sistema de KPIs y métricas de taller con arquitectura Medallion (Bronze/Silver/Gold). Consolida datos desde Business Central y StampingTaller en una capa analítica unificada.',
          children: [
            {
              id: 'analytics-problema',
              type: 'leaf',
              title: 'El problema de los datos',
              blocks: [
                {
                  kind: 'context',
                  label: 'Por qué no bastaba con reportes directos',
                  body: 'Los datos operativos del taller vivían en dos fuentes distintas: Business Central (la fuente financiera y de ERP) y StampingTaller (la fuente operativa en tiempo real). Reportar contra cualquiera de las dos directamente generaba consultas pesadas que afectaban el rendimiento de los sistemas transaccionales.',
                },
                {
                  kind: 'outcome',
                  label: 'La necesidad real',
                  body: 'La gerencia necesitaba KPIs que cruzaran ambas fuentes: tiempo real del taller vs. lo facturado en BC. Ese cruce no existía en ninguno de los dos sistemas por separado.',
                },
              ],
            },
            {
              id: 'analytics-arquitectura',
              type: 'leaf',
              title: 'Arquitectura Medallion',
              blocks: [
                {
                  kind: 'decision',
                  label: 'Por qué Medallion (Bronze / Silver / Gold)',
                  body: 'La arquitectura Medallion permite ingestar datos crudos sin transformarlos (Bronze), limpiarlos y conformarlos a un modelo común (Silver) y construir agregaciones listas para consumo analítico (Gold). Esto separa el problema de la ingesta del problema del reporte — los consumidores solo ven datos Gold, nunca el ruido de las fuentes.',
                },
                {
                  kind: 'built',
                  label: 'Las fuentes',
                  body: 'Bronze ingesta directamente desde el SQL Server de BC y desde el SQL Server de StampingTaller. Silver hace la conformación de entidades comunes (órdenes, mecánicos, trabajos). Gold agrega los KPIs por período, por mecánico, por tipo de trabajo.',
                },
                {
                  kind: 'stack',
                  label: 'Stack',
                  body: 'SQL Server · Arquitectura Medallion · ETL personalizado · Business Central SQL Source · StampingTaller SQL Source',
                },
              ],
            },
          ],
        },

        {
          id: 'agenda',
          type: 'section',
          scope: 'PROYECTO',
          eyebrow: 'Gestión operativa',
          title: 'Agenda Taller',
          description:
            'Sistema para gestionar y organizar actividades operativas del taller. Centraliza información, coordina procesos y facilita el seguimiento de trabajos.',
          children: [
            {
              id: 'agenda-que',
              type: 'leaf',
              title: 'Qué resuelve',
              blocks: [
                {
                  kind: 'context',
                  label: 'El problema de coordinación',
                  body: 'Sin un sistema centralizado, la coordinación de actividades del taller dependía de comunicación informal: llamadas, mensajes y memoria. El resultado era duplicidad de trabajo, tareas olvidadas y sin visibilidad de quién hacía qué.',
                },
                {
                  kind: 'built',
                  label: 'La solución',
                  body: 'Una plataforma que centraliza la agenda operativa: registro de actividades, asignación, seguimiento y cierre. Cualquier persona del equipo puede ver el estado actual de los trabajos en curso sin tener que preguntar.',
                },
              ],
            },
          ],
        },

        {
          id: 'checklist',
          type: 'section',
          scope: 'PROYECTO',
          eyebrow: 'Control de procesos',
          title: 'Checklist',
          description:
            'Herramienta que convierte procedimientos operativos en flujos verificables. Registra evidencia y facilita auditorías internas.',
          children: [
            {
              id: 'checklist-que',
              type: 'leaf',
              title: 'Checklists como sistema de control',
              blocks: [
                {
                  kind: 'context',
                  label: 'El insight',
                  body: 'Un procedimiento escrito en un manual no garantiza que se ejecute correctamente. Un checklist digital sí: cada paso debe marcarse, puede requerir evidencia fotográfica y queda registrado con fecha, hora y responsable.',
                },
                {
                  kind: 'built',
                  label: 'Qué se construyó',
                  body: 'Una herramienta que permite definir listas de verificación estructuradas por tipo de proceso, asignarlas a trabajos específicos y registrar la evidencia de cumplimiento. Los resultados son consultables para auditorías.',
                },
                {
                  kind: 'outcome',
                  label: 'El valor',
                  body: 'Los procedimientos dejan de depender de la memoria o el criterio individual de quien ejecuta. La operación se vuelve auditable y mejorable porque hay datos de lo que se hizo y lo que se omitió.',
                },
              ],
            },
          ],
        },

        {
          id: 'minecon-web',
          type: 'section',
          scope: 'PROYECTO',
          eyebrow: 'Presencia digital corporativa',
          title: 'minecon.com.do',
          description:
            'Rebuild completo del sitio web corporativo de MINECON en Angular. Home page completa, 8 páginas generales en proceso.',
          children: [
            {
              id: 'minecon-web-que',
              type: 'leaf',
              title: 'El proyecto',
              blocks: [
                {
                  kind: 'context',
                  label: 'Contexto',
                  body: 'El sitio anterior no representaba la escala y seriedad del grupo empresarial. El rebuild tiene como objetivo una presencia digital que esté a la altura de los clientes de MINECON: empresas corporativas del sector automotriz e industrial.',
                },
                {
                  kind: 'stack',
                  label: 'Stack',
                  body: 'Angular · SSR/SSG · Diseño corporativo',
                },
              ],
            },
          ],
        },
      ],
    },

    // ── SYNSET ──────────────────────────────────────────────────────────────
    {
      id: 'synset',
      type: 'chapter',
      scope: 'CO-FOUNDER',
      eyebrow: 'Co-Founder & Technical Lead',
      title: 'Synset Solutions',
      description:
        'Lo que construimos cuando decidimos que podíamos resolver problemas empresariales con software propio. Aquí tomo decisiones de arquitectura desde el inicio — sin heredar deuda técnica ajena.',
      children: [
        {
          id: 'tucolmado',
          type: 'section',
          scope: 'PROYECTO',
          eyebrow: 'POS/ERP · Comercio dominicano',
          title: 'TuColmadoRD',
          description:
            'POS/ERP híbrido cloud-local para colmados dominicanos. Diseñado para operar sin conexión y sincronizar cuando hay red.',
          children: [
            {
              id: 'tucolmado-problema',
              type: 'leaf',
              title: 'El problema del colmado',
              blocks: [
                {
                  kind: 'context',
                  label: 'Contexto de mercado',
                  body: 'Los colmados son el comercio minorista más común en República Dominicana — pequeños negocios de barrio que operan con registro manual de inventario, cuentas en libreta y sin datos. Digitalizarlos tiene un problema central: la conectividad es inconsistente.',
                },
                {
                  kind: 'decision',
                  label: 'El diseño cloud-local',
                  body: 'El sistema opera completamente offline con SQLite local y sincroniza con PostgreSQL en la nube cuando hay conexión. El patrón Outbox garantiza que ninguna transacción se pierda durante periodos sin red. El dueño del colmado nunca ve un error de conexión — el sistema simplemente sigue funcionando.',
                },
              ],
            },
            {
              id: 'tucolmado-arquitectura',
              type: 'leaf',
              title: 'La arquitectura del monorepo',
              blocks: [
                {
                  kind: 'built',
                  label: 'Qué hay en el monorepo',
                  body: 'Backend en .NET 9 con Clean Architecture, web admin en Angular 19, landing en Vue 3 (para una tecnología más liviana en marketing), servicio de autenticación en Node.js independiente. Cada pieza tiene su razón de existir.',
                },
                {
                  kind: 'decision',
                  label: 'RS256 para licencias',
                  body: 'Los tenants tienen licencias firmadas con RS256. El servidor de licencias es la única fuente de verdad de qué instancias están activas y qué capacidades tienen. Esto permite desactivar instancias remotamente sin tocar el código del cliente.',
                },
                {
                  kind: 'stack',
                  label: 'Stack',
                  body: '.NET 9 · Angular 19 (web admin) · Vue 3 (landing) · Node.js (auth) · PostgreSQL + SQLite · Outbox Pattern · RS256',
                },
              ],
            },
          ],
        },

        {
          id: 'fleetcore',
          type: 'section',
          scope: 'PROYECTO',
          eyebrow: 'EMM/MDM · Android Enterprise',
          title: 'FleetCore',
          description:
            'Plataforma EMM/MDM Android empresarial que opera sin Google Mobile Services. SaaS multi-tenant con tres tiers de precios.',
          children: [
            {
              id: 'fleetcore-problema',
              type: 'leaf',
              title: 'MDM sin Google',
              blocks: [
                {
                  kind: 'context',
                  label: 'Por qué existe FleetCore',
                  body: 'La gestión de dispositivos Android empresariales normalmente depende de Google Mobile Services (GMS) y de Android Enterprise. Para empresas con dispositivos AOSP sin GMS — o que no quieren depender del ecosistema de Google — las opciones son limitadas y caras.',
                },
                {
                  kind: 'decision',
                  label: 'DPC nativo sin GMS',
                  body: 'El agente Kotlin implementa Device Policy Controller (DPC) de forma nativa en AOSP. No requiere GMS, no requiere Google Workspace, no requiere ninguna cuenta de Google en el dispositivo. Funciona offline-first y sincroniza cuando hay red.',
                },
                {
                  kind: 'built',
                  label: 'Lo que gestiona',
                  body: 'Configuración de dispositivos, restricciones de aplicaciones, políticas de seguridad, monitoreo de estado en tiempo real vía WebSocket y telemetría histórica en TimescaleDB.',
                },
              ],
            },
            {
              id: 'fleetcore-negocio',
              type: 'leaf',
              title: 'El modelo de negocio',
              blocks: [
                {
                  kind: 'context',
                  label: 'SaaS tiered',
                  body: 'Tres planes por volumen de dispositivos: Starter ($79/mes), Business ($179/mes), Enterprise ($320/mes). El dashboard es multi-tenant — cada empresa ve solo sus dispositivos, sus políticas y sus alertas.',
                },
                {
                  kind: 'stack',
                  label: 'Stack',
                  body: '.NET 9 · Angular 19 (dashboard) · Kotlin (agente Android, offline-first) · WebSocket · Redis · TimescaleDB · AOSP DPC',
                },
              ],
            },
          ],
        },

        {
          id: 'nexusbilling',
          type: 'section',
          scope: 'PROYECTO',
          eyebrow: 'Facturación electrónica · RD',
          title: 'NexusBilling',
          description:
            'Plataforma de facturación electrónica para República Dominicana. DDD y Clean Architecture centrada en el dominio del negocio.',
          children: [
            {
              id: 'nexus-dominio',
              type: 'leaf',
              title: 'Por qué DDD aquí',
              blocks: [
                {
                  kind: 'context',
                  label: 'El dominio de la facturación',
                  body: 'La facturación electrónica en RD tiene reglas de negocio complejas, terminología legal propia y cambios regulatorios frecuentes. Es exactamente el tipo de dominio donde DDD tiene sentido: el lenguaje del negocio y el lenguaje del código deben ser el mismo.',
                },
                {
                  kind: 'decision',
                  label: 'Clean Architecture como límite',
                  body: 'El core del dominio no depende de ningún framework, ninguna base de datos ni ningún protocolo de facturación específico. Eso significa que cuando la DGII cambia el formato de los comprobantes, solo cambia la capa de infraestructura — las reglas de negocio no se tocan.',
                },
                {
                  kind: 'outcome',
                  label: 'La visión',
                  body: 'NexusBilling representa la visión de Synset de sistemas empresariales: software que dura, que escala y que otras empresas pueden adoptar sin necesidad de reescribir su lógica de negocio.',
                },
              ],
            },
          ],
        },

        {
          id: 'synset-infra',
          type: 'section',
          scope: 'PROYECTO',
          eyebrow: 'Infraestructura propia',
          title: 'Infraestructura Synset',
          description:
            'synsetserverchi: Ubuntu 24.04 con Dokploy + Traefik + Docker. Toda la infraestructura de Synset corre aquí.',
          children: [
            {
              id: 'infra-que',
              type: 'leaf',
              title: 'Qué corre en el servidor',
              blocks: [
                {
                  kind: 'built',
                  label: 'Servicios activos',
                  body: 'n8n (automatización de flujos), WAHA + chatbot para WhatsApp y Telegram, Gitea (repositorios propios), OpenCloud (almacenamiento), Uptime Kuma (monitoreo). Todo bajo Traefik con TLS automático y el dominio synsetsolutions.com.',
                },
                {
                  kind: 'decision',
                  label: 'Por qué infraestructura propia',
                  body: 'Tener control total sobre la infraestructura significa poder experimentar, desplegar y aprender sin costos de servicios gestionados para cada herramienta. También es donde probamos configuraciones antes de recomendarlas a clientes.',
                },
                {
                  kind: 'stack',
                  label: 'Stack',
                  body: 'Ubuntu 24.04 · Dokploy · Traefik · Docker · n8n · WAHA · Gitea · OpenCloud · Uptime Kuma',
                },
              ],
            },
          ],
        },
      ],
    },

    // ── PERSONAL ─────────────────────────────────────────────────────────────
    {
      id: 'personal',
      type: 'chapter',
      scope: 'PROYECTO',
      eyebrow: 'Proyectos independientes',
      title: 'Proyectos Propios',
      description:
        'Lo que construyo cuando el único cliente soy yo. Sin requisitos de negocio externos, sin plazos corporativos. Aquí experimento con ideas que me parecen interesantes o resuelvo problemas que veo en el mundo.',
      children: [
        {
          id: 'lintab',
          type: 'section',
          scope: 'PROYECTO',
          eyebrow: 'Hardware + Software · Linux',
          title: 'Lintab',
          description:
            'Controlador y aplicación para transformar smartphones en tabletas de dibujo digitalizadoras en Linux. Monorepo con Rust, Kotlin y TypeScript.',
          children: [
            {
              id: 'lintab-que',
              type: 'leaf',
              title: 'La idea',
              blocks: [
                {
                  kind: 'context',
                  label: 'El problema que resuelve',
                  body: 'Las tabletas de dibujo digitalizadoras para Linux son caras y tienen soporte limitado. Los smartphones modernos tienen pantallas táctiles de alta precisión que podrían funcionar como tablets de dibujo — pero no existe un puente estándar entre Android y el subsistema de input de Linux.',
                },
                {
                  kind: 'built',
                  label: 'Cómo funciona',
                  body: 'Un agente en Kotlin en el teléfono captura los eventos de touch con precisión de presión y posición. Un controlador en Rust en Linux los traduce a eventos de input del kernel (uinput). Una aplicación en TypeScript gestiona la configuración y la conexión.',
                },
                {
                  kind: 'decision',
                  label: 'Por qué Rust para el controlador',
                  body: 'El controlador de input vive en el espacio de sistema — latencia mínima, zero-cost abstractions y acceso seguro a las syscalls de uinput. Rust es la elección correcta cuando necesitas rendimiento de C con seguridad de memoria.',
                },
                {
                  kind: 'stack',
                  label: 'Stack',
                  body: 'Rust (controlador Linux / uinput) · Kotlin (agente Android) · TypeScript (app de configuración) · Monorepo',
                },
              ],
            },
          ],
        },

        {
          id: 'formalizate',
          type: 'section',
          scope: 'PROYECTO',
          eyebrow: 'Pre-seed · Marketplace RD',
          title: 'Formalizate RD',
          description:
            'Marketplace digital para conectar y formalizar trabajadores informales en República Dominicana. Nació como entregable académico en ITLA, hoy es un proyecto real bajo Synset.',
          children: [
            {
              id: 'formalizate-vision',
              type: 'leaf',
              title: 'La visión',
              blocks: [
                {
                  kind: 'context',
                  label: 'El problema de la informalidad',
                  body: 'Una parte significativa de la fuerza laboral dominicana trabaja en la informalidad — sin contratos, sin acceso a servicios financieros formales y sin visibilidad para clientes que buscan sus servicios. La informalidad no es elección; es falta de acceso a herramientas de formalización.',
                },
                {
                  kind: 'built',
                  label: 'Qué propone',
                  body: 'Una plataforma que conecta trabajadores informales (plomeros, electricistas, técnicos, etc.) con clientes, gestiona contratos simples, pagos y reputación. El objetivo es que la formalización sea una consecuencia natural del uso de la plataforma, no un requisito previo.',
                },
                {
                  kind: 'outcome',
                  label: 'Estado actual',
                  body: 'Pre-seed. Objetivo de US$150k para el primer round. Desarrollado originalmente como Plan de Negocios para ITLA, hoy bajo Synset Solutions como proyecto propio.',
                },
              ],
            },
          ],
        },

        {
          id: 'tecto',
          type: 'section',
          scope: 'PROYECTO',
          eyebrow: 'Laboratorio técnico',
          title: 'Tecto',
          description:
            'Espacio de experimentación técnica. Explorar ideas, tecnologías y enfoques sin las restricciones de un entorno empresarial.',
          children: [
            {
              id: 'tecto-que',
              type: 'leaf',
              title: 'Por qué existe Tecto',
              blocks: [
                {
                  kind: 'context',
                  label: 'El problema de aprender en producción',
                  body: 'En el trabajo, las decisiones técnicas tienen consecuencias reales — no es el lugar para probar algo que no has entendido bien. Tecto es el espacio donde puedo experimentar con tecnologías nuevas, explorar enfoques alternativos y aprender sin el costo de romper algo en producción.',
                },
                {
                  kind: 'outcome',
                  label: 'Lo que produce',
                  body: 'Prototipos, exploraciones, herramientas pequeñas. No todo lo que pasa por Tecto termina en producción — y ese es exactamente el punto.',
                },
              ],
            },
          ],
        },
      ],
    },

    // ── ACADÉMICO / ITLA ─────────────────────────────────────────────────────
    {
      id: 'academico',
      type: 'chapter',
      scope: 'ACADÉMICO',
      eyebrow: 'ITLA · Formación',
      title: 'Formación · ITLA',
      description:
        'Donde aprendí los fundamentos que uso hoy. Estos proyectos no son para impresionar — son para mostrar de dónde vienen las decisiones que tomo ahora.',
      children: [
        {
          id: 'hermes',
          type: 'section',
          scope: 'ACADÉMICO',
          eyebrow: 'Sistema bancario completo',
          title: 'HermesBanking',
          description:
            'Sistema bancario completo con Onion Architecture, CQRS y MediatR. No desplegado por requerir infraestructura bancaria especializada.',
          children: [
            {
              id: 'hermes-que',
              type: 'leaf',
              title: 'Lo que construí',
              blocks: [
                {
                  kind: 'built',
                  label: 'El sistema',
                  body: 'Cuentas bancarias, transacciones, transferencias, historial de movimientos. La parte técnica interesante no fue el CRUD — fue implementar Onion Architecture y CQRS con MediatR en un proyecto donde tenía libertad de diseño total.',
                },
                {
                  kind: 'outcome',
                  label: 'El aprendizaje real',
                  body: 'HermesBanking fue donde entendí por qué la arquitectura importa. No porque alguien me lo dijera — porque lo implementé, lo rompí, lo rediseñé y lo implementé de nuevo. Esa experiencia llegó a StampingTaller.',
                },
                {
                  kind: 'stack',
                  label: 'Stack',
                  body: 'ASP.NET Core MVC · Onion Architecture · CQRS · MediatR · JWT · SQL Server',
                },
              ],
            },
          ],
        },

        {
          id: 'itlanetworking',
          type: 'section',
          scope: 'ACADÉMICO',
          eyebrow: 'Red social con Battleship',
          title: 'ITLANetworking',
          description:
            'Red social con autenticación, gestión de amistades, publicaciones multimedia y Battleship integrado.',
          children: [
            {
              id: 'itlanet-que',
              type: 'leaf',
              title: 'El proyecto',
              blocks: [
                {
                  kind: 'built',
                  label: 'Qué incluye',
                  body: 'Autenticación, perfiles, amistades, publicaciones con imágenes, y un juego de Battleship jugable entre usuarios conectados. El Battleship fue la parte que más me obligó a pensar en estado compartido y sincronización.',
                },
                {
                  kind: 'stack',
                  label: 'Stack',
                  body: 'ASP.NET Core MVC · Onion Architecture · Repository Pattern · SQL Server',
                },
              ],
            },
          ],
        },

        {
          id: 'appcenar',
          type: 'section',
          scope: 'ACADÉMICO',
          eyebrow: 'App de delivery',
          title: 'AppCenar',
          description:
            'Aplicación de delivery que conecta clientes, comercios y repartidores.',
          children: [
            {
              id: 'appcenar-que',
              type: 'leaf',
              title: 'El proyecto',
              blocks: [
                {
                  kind: 'context',
                  label: 'Contexto',
                  body: 'Un proyecto que requería modelar tres actores con flujos distintos: el cliente pide, el comercio prepara, el repartidor entrega. Cada actor tiene su vista, sus acciones y su estado.',
                },
                {
                  kind: 'stack',
                  label: 'Stack',
                  body: 'Node.js · Express · MVC · MySQL',
                },
              ],
            },
          ],
        },

        {
          id: 'montecarlo',
          type: 'section',
          scope: 'ACADÉMICO',
          eyebrow: 'Computación paralela',
          title: 'Simulación Monte Carlo SIR-D',
          description:
            'Simulación epidémica paralela con análisis de Ley de Amdahl.',
          children: [
            {
              id: 'montecarlo-que',
              type: 'leaf',
              title: 'El proyecto',
              blocks: [
                {
                  kind: 'context',
                  label: 'Por qué es interesante',
                  body: 'Implementar Monte Carlo para un modelo SIR-D (Susceptible, Infectado, Recuperado, Muerto) requiere miles de simulaciones paralelas. El ejercicio real fue medir el speedup y validar empíricamente la Ley de Amdahl — la parte del código que no puede paralelizarse limita el beneficio de agregar más cores.',
                },
                {
                  kind: 'outcome',
                  label: 'El aprendizaje',
                  body: 'La primera vez que escribí código que realmente importa en qué hardware corre. Eso cambia cómo piensas sobre el rendimiento.',
                },
              ],
            },
          ],
        },
      ],
    },

    // ── QUIÉN SOY ────────────────────────────────────────────────────────────
    {
      id: 'identidad',
      type: 'chapter',
      scope: 'IDENTIDAD',
      eyebrow: 'Francisco Castro',
      title: 'Quién Soy',
      description:
        'No el perfil de LinkedIn. Cómo pienso sobre el software y por qué trabajo de la forma en que trabajo.',
      children: [
        {
          id: 'filosofia',
          type: 'leaf',
          title: 'Filosofía de ingeniería',
          blocks: [
            {
              kind: 'quote',
              label: 'La brújula',
              body: 'No quiero mostrar lo que he hecho; quiero mostrar cómo cada experiencia me convirtió en el ingeniero que soy hoy.',
            },
            {
              kind: 'context',
              label: 'Sobre la arquitectura',
              body: 'La arquitectura limpia no es un fin en sí misma — es el medio para que el sistema evolucione sin romper lo que ya funciona. Cada patrón que uso tiene que poder justificarse con "el dominio lo requiere", no "es lo que está de moda".',
            },
            {
              kind: 'decision',
              label: 'Sobre la complejidad',
              body: 'Si no puedes explicar por qué necesitas la complejidad que introduces, probablemente no la necesitas. Tres capas de abstracción para un CRUD simple no es Clean Architecture — es sobreingeniería.',
            },
            {
              kind: 'outcome',
              label: 'Sobre el negocio',
              body: 'El software que construyo existe para resolver problemas reales de negocio. Entender el dominio — no solo el código — es lo que diferencia un sistema que dura de uno que se reescribe en dos años.',
            },
          ],
        },
        {
          id: 'hoy',
          type: 'leaf',
          title: 'El desarrollador de hoy',
          blocks: [
            {
              kind: 'context',
              label: 'Dónde estoy',
              body: 'Desarrollador de software en MINECON S.A. (2022–presente) y co-fundador de Synset Solutions. Trabajo en República Dominicana construyendo e integrando sistemas empresariales.',
            },
            {
              kind: 'built',
              label: 'Lo que hago bien',
              body: 'Diseño e integro sistemas orientados a procesos de negocio. Me muevo entre el dominio de negocio y la infraestructura técnica con igual comodidad. Business Central, .NET, SQL Server y APIs REST no son tecnologías que uso — son herramientas que entiendo.',
            },
            {
              kind: 'stack',
              label: 'Stack principal',
              body: 'C# · .NET 8/9 · SQL Server · Angular 18/19 · TypeScript · Business Central · Clean Architecture · CQRS',
            },
            {
              kind: 'outcome',
              label: 'Contacto',
              body: 'fcastro.info · República Dominicana · Trabajo remoto disponible',
            },
          ],
        },
      ],
    },

    // ── ACTIVIDAD ────────────────────────────────────────────────────────────
    {
      id: 'actividad',
      type: 'chapter',
      scope: 'EVIDENCIA',
      eyebrow: 'GitHub · 12 meses',
      title: 'Actividad Técnica',
      description: 'El código como evidencia. No como decoración.',
      children: [
        {
          id: 'github-evidencia',
          type: 'leaf',
          title: 'GitHub como evidencia',
          blocks: [
            {
              kind: 'context',
              label: 'Por qué importa',
              body: '700+ commits en 12 meses. 245+ pull requests. 70%+ del código en C#. Esto no es vanidad — es la diferencia entre decir que sabes algo y demostrar que lo practicas.',
            },
            {
              kind: 'stack',
              label: 'Distribución de lenguajes',
              body: 'C# · TypeScript · SQL · AL (Business Central Extensions) · Kotlin · Rust · HTML/CSS',
            },
            {
              kind: 'outcome',
              label: 'Lo que dice el patrón',
              body: 'La mayoría del trabajo es backend empresarial: integraciones, APIs, automatizaciones, arquitectura. No hay mucho frontend porque no es donde vivo. El Rust y Kotlin aparecen por Lintab — proyectos propios donde tengo libertad de elegir el stack correcto para el problema.',
            },
          ],
        },
      ],
    },
  ],
};

export function findNode(id: string, node: TreeNode = TREE): TreeNode | null {
  if (node.id === id) return node;
  for (const child of node.children ?? []) {
    const found = findNode(id, child);
    if (found) return found;
  }
  return null;
}

export function resolvePathNodes(path: string[]): TreeNode[] {
  const nodes: TreeNode[] = [TREE];
  let current: TreeNode = TREE;
  for (const id of path) {
    const child = current.children?.find((c) => c.id === id);
    if (!child) break;
    nodes.push(child);
    current = child;
  }
  return nodes;
}
