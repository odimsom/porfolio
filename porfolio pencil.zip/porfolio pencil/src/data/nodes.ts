export interface BentoCard {
  type: 'stat' | 'text' | 'tag-list' | 'link' | 'code';
  label?: string;
  value?: string;
  items?: string[];
  href?: string;
  span?: 1 | 2;
}

export type NodeScope = 'IDENTIDAD' | 'EXPERIENCIA' | 'CO-FOUNDER' | 'PROYECTO' | 'EVIDENCIA' | 'FILOSOFÍA' | 'CONTACTO';

export interface PortfolioNode {
  id: string;
  step: number;
  x: number;
  y: number;
  width: number;
  height: number;
  scope: NodeScope;
  title: string;
  subtitle: string;
  eyebrow?: string;       // small label above title in idle
  tags: string[];
  cards: BentoCard[];
}

export const PORTFOLIO_NODES: PortfolioNode[] = [
  {
    id: 'hero',
    step: 0,
    x: 560,
    y: 320,
    width: 560,
    height: 300,
    scope: 'IDENTIDAD',
    title: 'Francisco Castro',
    eyebrow: 'Software Developer',
    subtitle: 'Enterprise Systems & Integrations',
    tags: ['.NET', 'C#', 'SQL Server', 'Business Central', 'APIs'],
    cards: [
      {
        type: 'text',
        span: 2,
        value:
          'Diseño, desarrollo e integro software empresarial. Me especializo en sistemas orientados a procesos de negocio, automatización e integración de plataformas.',
      },
      { type: 'link', label: 'fcastro.info', href: 'https://fcastro.info' },
      { type: 'link', label: 'GitHub', href: 'https://github.com/fcastro' },
    ],
  },
  {
    id: 'minecon',
    step: 1,
    x: 1300,
    y: 280,
    width: 520,
    height: 400,
    scope: 'EXPERIENCIA',
    eyebrow: '2022 — Presente',
    title: 'MINECON S.A.',
    subtitle: 'Desarrollador de Software',
    tags: ['.NET', 'Business Central', 'SQL Server', 'REST APIs', 'Azure'],
    cards: [
      {
        type: 'text',
        span: 2,
        value:
          'Desarrollo e integración de sistemas empresariales para distintas compañías del grupo corporativo. Automatización de procesos de logística, inventario, servicio y contabilidad.',
      },
      { type: 'stat', label: 'Sistemas integrados', value: '8+' },
      { type: 'stat', label: 'APIs desarrolladas', value: '15+' },
      {
        type: 'tag-list',
        label: 'Stack',
        items: ['ASP.NET Core', 'Dynamics 365 BC', 'T-SQL', 'SignalR', 'Azure DevOps'],
        span: 2,
      },
    ],
  },
  {
    id: 'synset',
    step: 2,
    x: 2050,
    y: 200,
    width: 460,
    height: 380,
    scope: 'CO-FOUNDER',
    eyebrow: 'Synset Solutions',
    title: 'Technical Lead',
    subtitle: 'Co-Founder · Startup de software empresarial',
    tags: ['Startup', '.NET', 'Angular', 'PostgreSQL', 'Cloud'],
    cards: [
      {
        type: 'text',
        span: 2,
        value:
          'Co-fundador y líder técnico. Definición de arquitectura, decisiones de stack, revisión de código y entrega de productos para clientes empresariales en RD.',
      },
      { type: 'stat', label: 'Productos', value: '4' },
      { type: 'stat', label: 'Clientes', value: '3+' },
      {
        type: 'tag-list',
        label: 'Responsabilidades',
        items: ['Arquitectura', 'Code Review', 'DevOps', 'Mentoring'],
        span: 2,
      },
    ],
  },
  {
    id: 'stamping',
    step: 3,
    x: 560,
    y: 900,
    width: 500,
    height: 420,
    scope: 'PROYECTO',
    eyebrow: 'StampingTaller',
    title: 'Gestión de Taller',
    subtitle: 'Sistema completo de operaciones industriales',
    tags: ['.NET 8', 'Angular 17', 'Clean Arch', 'CQRS', 'SignalR'],
    cards: [
      {
        type: 'text',
        span: 2,
        value:
          'Plataforma completa para gestión de órdenes de trabajo, mecánicos, asignación de tareas y seguimiento de tiempo en tiempo real. Integrado con Business Central via API.',
      },
      { type: 'stat', label: 'Módulos', value: '7' },
      { type: 'stat', label: 'Endpoints', value: '40+' },
      {
        type: 'code',
        label: 'Stack',
        value: 'ASP.NET Core · MediatR · EF Core\nAngular 17 · SignalR · BC Integration',
        span: 2,
      },
    ],
  },
  {
    id: 'agenda',
    step: 4,
    x: 1300,
    y: 880,
    width: 480,
    height: 400,
    scope: 'PROYECTO',
    eyebrow: 'Agenda Taller',
    title: 'Plataforma de Agendamiento',
    subtitle: 'Integrado con Business Central',
    tags: ['Node.js', 'Angular', 'PostgreSQL', 'BC API', 'Docker'],
    cards: [
      {
        type: 'text',
        span: 2,
        value:
          'Sistema de agenda y checklist para talleres mecánicos con integración a Business Central. Gestión de citas, checklists técnicos y notificaciones automáticas.',
      },
      { type: 'stat', label: 'Módulos', value: '5' },
      {
        type: 'tag-list',
        label: 'Features',
        items: ['Agenda web', 'Checklists', 'Email automático', 'BC Sync'],
        span: 2,
      },
    ],
  },
  {
    id: 'github',
    step: 5,
    x: 2050,
    y: 860,
    width: 440,
    height: 360,
    scope: 'EVIDENCIA',
    eyebrow: 'GitHub · 12 meses',
    title: 'Actividad Técnica',
    subtitle: 'Código como prueba, no como decoración',
    tags: ['C#', 'TypeScript', 'Open Source'],
    cards: [
      { type: 'stat', label: 'Commits (12 meses)', value: '700+' },
      { type: 'stat', label: 'Pull Requests', value: '245+' },
      { type: 'stat', label: 'Código en C#', value: '70%+' },
      { type: 'stat', label: 'Repos activos', value: '12+' },
      {
        type: 'tag-list',
        label: 'Lenguajes',
        items: ['C#', 'TypeScript', 'SQL', 'AL (BC)'],
        span: 2,
      },
    ],
  },
  {
    id: 'philosophy',
    step: 6,
    x: 1050,
    y: 1500,
    width: 580,
    height: 360,
    scope: 'FILOSOFÍA',
    eyebrow: 'Ingeniería de Software',
    title: 'Cómo Pienso',
    subtitle: 'Principios que guían cada decisión técnica',
    tags: ['Clean Code', 'Architecture', 'Process'],
    cards: [
      {
        type: 'text',
        span: 2,
        value:
          '"El código bien escrito no necesita comentarios que expliquen qué hace — solo por qué existe."',
      },
      {
        type: 'text',
        span: 2,
        value:
          'Priorizo sistemas que resuelven problemas reales de negocio, no soluciones en busca de un problema. La arquitectura limpia no es un fin en sí misma — es el medio para que el sistema evolucione sin romper lo que ya funciona.',
      },
    ],
  },
  {
    id: 'contact',
    step: 7,
    x: 1050,
    y: 2050,
    width: 480,
    height: 280,
    scope: 'CONTACTO',
    eyebrow: 'República Dominicana · Remote',
    title: 'Hablemos',
    subtitle: 'De lo que puedo construir para ti',
    tags: ['Disponible', 'RD · Remote'],
    cards: [
      { type: 'link', label: 'fcastro.info', href: 'https://fcastro.info', span: 2 },
      { type: 'link', label: 'LinkedIn', href: 'https://linkedin.com/in/fcastro' },
      { type: 'link', label: 'GitHub', href: 'https://github.com/fcastro' },
      {
        type: 'text',
        span: 2,
        value: 'República Dominicana · Trabajo remoto disponible',
      },
    ],
  },
];
