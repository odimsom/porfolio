import { create } from 'zustand';
import type { TourStatus } from '../core/tour-engine';

interface CameraState { x: number; y: number; scale: number }

interface CanvasStore {
  x: number;
  y: number;
  scale: number;
  tourStatus: TourStatus;
  isDragging: boolean;
  cameraHistory: CameraState[];

  setCamera: (x: number, y: number, scale: number) => void;
  setPosition: (x: number, y: number) => void;
  setScale: (scale: number) => void;
  setTourStatus: (status: TourStatus) => void;
  setDragging: (v: boolean) => void;
  pushCamera: (nextX: number, nextY: number, nextScale: number) => void;
  popCamera: () => void;
}

export const useCanvasStore = create<CanvasStore>((set, get) => ({
  x: 0,
  y: 0,
  scale: 0.72,
  tourStatus: 'idle',
  isDragging: false,
  cameraHistory: [],

  setCamera:   (x, y, scale) => set({ x, y, scale }),
  setPosition: (x, y)        => set({ x, y }),
  setScale:    (scale)        => set({ scale }),
  setTourStatus: (tourStatus) => set({ tourStatus }),
  setDragging: (isDragging)   => set({ isDragging }),

  pushCamera: (nextX, nextY, nextScale) => {
    const { x, y, scale, cameraHistory } = get();
    set({
      cameraHistory: [...cameraHistory, { x, y, scale }],
      x: nextX, y: nextY, scale: nextScale,
    });
  },

  popCamera: () => {
    const { cameraHistory } = get();
    if (!cameraHistory.length) return;
    const prev = cameraHistory[cameraHistory.length - 1];
    set({ cameraHistory: cameraHistory.slice(0, -1), x: prev.x, y: prev.y, scale: prev.scale });
  },
}));
