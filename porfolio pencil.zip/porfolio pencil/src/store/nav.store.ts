import { create } from 'zustand';
import { TREE, findNode, resolvePathNodes } from '../data/tree';
import type { TreeNode } from '../data/tree';

interface NavStore {
  path: string[];                     // IDs from root children downward
  currentNode: TreeNode;              // node at current path tip
  pathNodes: TreeNode[];              // all nodes from root to current (for breadcrumb)
  isTransitioning: boolean;

  push: (id: string) => void;
  pop: () => void;
  reset: () => void;
  setTransitioning: (v: boolean) => void;
}

export const useNavStore = create<NavStore>((set) => ({
  path: [],
  currentNode: TREE,
  pathNodes: [TREE],
  isTransitioning: false,

  push: (id) =>
    set((s) => {
      const newPath = [...s.path, id];
      const node = findNode(id) ?? TREE;
      return {
        path: newPath,
        currentNode: node,
        pathNodes: resolvePathNodes(newPath),
      };
    }),

  pop: () =>
    set((s) => {
      if (s.path.length === 0) return s;
      const newPath = s.path.slice(0, -1);
      const node = newPath.length === 0 ? TREE : findNode(newPath[newPath.length - 1]) ?? TREE;
      return {
        path: newPath,
        currentNode: node,
        pathNodes: resolvePathNodes(newPath),
      };
    }),

  reset: () =>
    set({
      path: [],
      currentNode: TREE,
      pathNodes: [TREE],
    }),

  setTransitioning: (v) => set({ isTransitioning: v }),
}));
