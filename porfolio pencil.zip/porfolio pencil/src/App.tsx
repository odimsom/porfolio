import { useRef } from 'react';
import { TransitionContext } from './components/nav/TransitionContext';
import { useNodeTransition } from './hooks/useNodeTransition';
import { useNavStore } from './store/nav.store';
import { useCanvasStore } from './store/canvas.store';
import CanvasScene from './components/canvas/CanvasScene';
import Breadcrumb from './components/nav/Breadcrumb';
import ExpandOverlay from './components/nav/ExpandOverlay';
import LeafView from './components/nav/LeafView';

export default function App() {
  const overlayRef = useRef<HTMLDivElement>(null);
  const { enter, back } = useNodeTransition(overlayRef);
  const { path, currentNode } = useNavStore();
  const popCamera = useCanvasStore((s) => s.popCamera);

  const isAtLeaf = currentNode.type === 'leaf';

  // Back from leaf goes to the canvas of the parent section
  // Back from section canvas goes to the chapter canvas
  // Back from chapter canvas goes to root canvas
  const handleBack = () => {
    popCamera();  // Restore camera position from the level we came from
    back();
  };

  return (
    <TransitionContext.Provider value={{ enter, back: handleBack }}>
      <ExpandOverlay ref={overlayRef} />

      {/* Canvas is always mounted — shows the current level's children */}
      <CanvasScene />

      {/* Breadcrumb shown on all levels except root */}
      {path.length > 0 && <Breadcrumb />}

      {/* Leaf content overlays the canvas */}
      {isAtLeaf && <LeafView node={currentNode} />}
    </TransitionContext.Provider>
  );
}
