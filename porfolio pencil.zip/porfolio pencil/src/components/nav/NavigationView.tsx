import { useNavStore } from '../../store/nav.store';
import RootView from './RootView';
import NodeCard from './NodeCard';
import LeafView from './LeafView';
import styles from './NavigationView.module.css';

export default function NavigationView() {
  const { path, currentNode } = useNavStore();

  const isRoot = path.length === 0;
  const isLeaf = !currentNode.children || currentNode.children.length === 0;

  if (isRoot) {
    return (
      <main className={styles.main}>
        <RootView />
      </main>
    );
  }

  if (isLeaf) {
    return (
      <main className={[styles.main, styles.leafMain].join(' ')}>
        <LeafView node={currentNode} />
      </main>
    );
  }

  // Chapter or section with children
  return (
    <main className={styles.main}>
      <div className={styles.chapterView}>
        <header className={styles.chapterHeader}>
          {currentNode.scope && (
            <span className={styles.scope}>{currentNode.scope}</span>
          )}
          {currentNode.eyebrow && (
            <span className={styles.eyebrow}>{currentNode.eyebrow}</span>
          )}
          <h1 className={styles.chapterTitle}>{currentNode.title}</h1>
          {currentNode.description && (
            <p className={styles.chapterDesc}>{currentNode.description}</p>
          )}
        </header>

        <div className={styles.grid}>
          {currentNode.children?.map((child, i) => (
            <NodeCard key={child.id} node={child} index={i} />
          ))}
        </div>
      </div>
    </main>
  );
}
