import NodeCard from './NodeCard';
import { TREE } from '../../data/tree';
import styles from './RootView.module.css';

export default function RootView() {
  return (
    <div className={styles.root}>
      <header className={styles.hero}>
        <span className={styles.mono}>fcastro.info</span>
        <h1 className={styles.name}>Francisco<br />Castro</h1>
        <p className={styles.role}>Software Developer · Enterprise Systems & Integrations</p>
        <p className={styles.sub}>República Dominicana · MINECON S.A. · Synset Solutions</p>
      </header>

      <div className={styles.grid}>
        {TREE.children?.map((chapter, i) => (
          <NodeCard key={chapter.id} node={chapter} index={i} />
        ))}
      </div>
    </div>
  );
}
