import { forwardRef } from 'react';
import styles from './ExpandOverlay.module.css';

const ExpandOverlay = forwardRef<HTMLDivElement>((_, ref) => (
  <div ref={ref} className={styles.overlay} aria-hidden />
));

ExpandOverlay.displayName = 'ExpandOverlay';
export default ExpandOverlay;
