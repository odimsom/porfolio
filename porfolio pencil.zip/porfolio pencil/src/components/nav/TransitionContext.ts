import { createContext } from 'react';
import type { TreeNode } from '../../data/tree';

interface TransitionCtx {
  enter: (node: TreeNode, cardEl: HTMLElement) => void;
  back: () => void;
}

export const TransitionContext = createContext<TransitionCtx>({
  enter: () => {},
  back: () => {},
});
