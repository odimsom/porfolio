import { useRef, useContext } from 'react';
import { TransitionContext } from './TransitionContext';
import type { TreeNode } from '../../data/tree';
import styles from './NodeCard.module.css';

interface Props {
  node: TreeNode;
  index?: number;
}

export default function NodeCard({ node }: Props) {
  const cardRef = useRef<HTMLDivElement>(null);
  const { enter } = useContext(TransitionContext);

  const isLeaf = !node.children || node.children.length === 0;
  const childCount = node.children?.length ?? 0;

  const handleClick = () => {
    if (cardRef.current) enter(node, cardRef.current);
  };

  return (
    <div
      ref={cardRef}
      data-card
      className={[styles.card, isLeaf ? styles.leaf : ''].join(' ')}
      onClick={handleClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && handleClick()}
      aria-label={`Entrar en ${node.title}`}
    >
      <div className={styles.top}>
        {node.scope && (
          <span className={styles.scope}>{node.scope}</span>
        )}
        {node.eyebrow && (
          <span className={styles.eyebrow}>{node.eyebrow}</span>
        )}
      </div>

      <div className={styles.body}>
        <h2 className={styles.title}>{node.title}</h2>
        {node.description && (
          <p className={styles.description}>{node.description}</p>
        )}
      </div>

      <div className={styles.foot}>
        {!isLeaf && (
          <span className={styles.childCount}>
            {childCount} {childCount === 1 ? 'sección' : 'secciones'}
          </span>
        )}
        <span className={styles.arrow}>{isLeaf ? 'Leer →' : 'Explorar →'}</span>
      </div>
    </div>
  );
}
