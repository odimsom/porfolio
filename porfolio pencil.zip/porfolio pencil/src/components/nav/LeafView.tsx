import { useContext } from 'react';
import { TransitionContext } from './TransitionContext';
import type { TreeNode, LeafBlock } from '../../data/tree';
import styles from './LeafView.module.css';

interface Props { node: TreeNode }

export default function LeafView({ node }: Props) {
  const { back } = useContext(TransitionContext);

  return (
    <div className={styles.overlay}>
      <div className={styles.panel}>
        <button className={styles.backBtn} onClick={back}>← Volver</button>

        <article className={styles.article}>
          <header className={styles.header}>
            <h1 className={styles.title}>{node.title}</h1>
          </header>

          <div className={styles.blocks}>
            {node.blocks?.map((block, i) => (
              <BlockItem key={i} block={block} />
            ))}
          </div>
        </article>
      </div>
    </div>
  );
}

function BlockItem({ block }: { block: LeafBlock }) {
  const isQuote = block.kind === 'quote';
  const isStack = block.kind === 'stack';

  return (
    <section className={[styles.block, isQuote ? styles.blockQuote : '', isStack ? styles.blockStack : ''].join(' ')}>
      <span className={styles.blockLabel}>{block.label}</span>
      {isQuote ? (
        <blockquote className={styles.quote}>&ldquo;{block.body}&rdquo;</blockquote>
      ) : isStack ? (
        <pre className={styles.stack}>{block.body}</pre>
      ) : (
        <p className={styles.body}>{block.body}</p>
      )}
    </section>
  );
}
