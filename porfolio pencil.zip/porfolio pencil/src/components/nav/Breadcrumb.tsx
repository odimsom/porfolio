import { useContext } from 'react';
import { useNavStore } from '../../store/nav.store';
import { TransitionContext } from './TransitionContext';
import styles from './Breadcrumb.module.css';

export default function Breadcrumb() {
  const { path, pathNodes } = useNavStore();
  const { back } = useContext(TransitionContext);

  if (path.length === 0) return null;

  return (
    <nav className={styles.nav} aria-label="Navegación">
      <button className={styles.backBtn} onClick={back} aria-label="Volver">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          <polyline points="15 18 9 12 15 6" />
        </svg>
        <span>Volver</span>
      </button>

      <ol className={styles.crumbs}>
        {pathNodes.map((node, i) => (
          <li key={node.id} className={styles.crumb}>
            {i > 0 && <span className={styles.sep}>/</span>}
            <span className={i === pathNodes.length - 1 ? styles.active : styles.inactive}>
              {node.id === 'root' ? 'FC' : node.title}
            </span>
          </li>
        ))}
      </ol>
    </nav>
  );
}
