import { useContext, useEffect, useRef } from 'react';
import { useCanvasStore } from '../../store/canvas.store';
import { TourEngine } from '../../core/tour-engine';
import { CanvasLevelContext } from '../../contexts/CanvasLevelContext';
import type { PortfolioNode } from '../../core/tour-engine';
import styles from './TourControls.module.css';

export default function TourControls() {
  const { nodes, levelId } = useContext(CanvasLevelContext);
  const { tourStatus, setTourStatus, setCamera } = useCanvasStore();
  const engineRef = useRef<TourEngine | null>(null);

  // Rebuild tour engine whenever the level changes (new set of nodes)
  useEffect(() => {
    engineRef.current?.stop();

    const tourNodes: PortfolioNode[] = nodes.map(({ node, pos }) => ({
      id: node.id,
      x: pos.x + pos.width / 2,
      y: pos.y + pos.height / 2,
    }));

    if (!tourNodes.length) return;

    engineRef.current = new TourEngine({
      nodes: tourNodes,
      getCamera: () => {
        const s = useCanvasStore.getState();
        return { x: s.x, y: s.y, scale: s.scale };
      },
      getVW: () => window.innerWidth,
      getVH: () => window.innerHeight,
      setCamera,
      setFocusedNode: () => {},
      setTourStatus,
      stepDuration: 3.5,
      travelDuration: 1.4,
    });

    return () => engineRef.current?.stop();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [levelId, setCamera, setTourStatus]);

  const handlePlay = () => {
    if (tourStatus === 'paused') engineRef.current?.resume();
    else engineRef.current?.play();
  };

  if (!nodes.length) return null;

  return (
    <div className={styles.controls}>
      {tourStatus === 'idle' && (
        <button className={styles.btn} onClick={handlePlay}>
          <PlayIcon /> <span>Tour</span>
        </button>
      )}
      {tourStatus === 'playing' && (
        <>
          <button className={styles.btn} onClick={() => engineRef.current?.pause()}><PauseIcon /></button>
          <button className={[styles.btn, styles.muted].join(' ')} onClick={() => engineRef.current?.stop()}><StopIcon /></button>
        </>
      )}
      {tourStatus === 'paused' && (
        <>
          <button className={styles.btn} onClick={handlePlay}><PlayIcon /></button>
          <button className={[styles.btn, styles.muted].join(' ')} onClick={() => engineRef.current?.stop()}><StopIcon /></button>
        </>
      )}
    </div>
  );
}

function PlayIcon() {
  return <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><polygon points="5,3 19,12 5,21" /></svg>;
}
function PauseIcon() {
  return <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16" /><rect x="14" y="4" width="4" height="16" /></svg>;
}
function StopIcon() {
  return <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><rect x="4" y="4" width="16" height="16" /></svg>;
}
