import { useThemeStore } from '../../store/theme.store';
import styles from './ThemeToggle.module.css';

export default function ThemeToggle() {
  const { theme, toggle } = useThemeStore();
  return (
    <button className={styles.btn} onClick={toggle} title="Cambiar tema" aria-label="Cambiar tema">
      {theme === 'dark' ? '☀' : '◑'}
    </button>
  );
}
