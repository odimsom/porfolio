import { useCanvasStore } from '../../store/canvas.store';
import { useThemeStore } from '../../store/theme.store';
import styles from './HUD.module.css';

export default function HUD() {
  const scale = useCanvasStore((s) => s.scale);
  const { theme, toggle } = useThemeStore();

  return (
    <div className={styles.hud}>
      <div className={styles.left}>
        <span className={styles.monogram}>FC</span>
        <span className={styles.sep}>·</span>
        <span className={styles.scale}>{Math.round(scale * 100)}%</span>
      </div>
      <button className={styles.themeBtn} onClick={toggle} title="Cambiar tema">
        {theme === 'dark' ? '☀' : '◑'}
      </button>
    </div>
  );
}
