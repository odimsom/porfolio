import { useRef, useContext } from 'react';
import { TransitionContext } from '../nav/TransitionContext';
import { useCanvasStore } from '../../store/canvas.store';
import type { TreeNode } from '../../data/tree';
import type { CanvasPosition } from '../../data/canvasLayout';
import styles from './CanvasNode.module.css';

interface Props {
  node: TreeNode;
  pos: CanvasPosition;
}

export default function CanvasNode({ node, pos }: Props) {
  const cardRef = useRef<HTMLDivElement>(null);
  const { enter } = useContext(TransitionContext);
  const tourStatus = useCanvasStore((s) => s.tourStatus);

  const isLeaf = node.type === 'leaf';
  const childCount = node.children?.length ?? 0;

  const handleClick = () => {
    if (tourStatus === 'playing') return;
    if (cardRef.current) enter(node, cardRef.current);
  };

  return (
    <div
      ref={cardRef}
      data-card
      data-node={node.id}
      className={`${styles.node} ${isLeaf ? styles.leafNode : ''}`}
      style={{ left: pos.x, top: pos.y, width: pos.width }}
      onClick={handleClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && handleClick()}
      aria-label={`${isLeaf ? 'Leer' : 'Entrar en'} ${node.title}`}
    >
      <div className={styles.top}>
        {node.scope && <span className={styles.scope}>{node.scope}</span>}
        {node.eyebrow && <span className={styles.eyebrow}>{node.eyebrow}</span>}
      </div>

      <h2 className={`${styles.title} ${isLeaf ? styles.leafTitle : ''}`}>{node.title}</h2>

      {node.description && (
        <p className={styles.desc}>{node.description}</p>
      )}

      {/* Leaf block preview */}
      {isLeaf && node.blocks && node.blocks.length > 0 && (
        <p className={styles.preview}>{node.blocks[0].body.slice(0, 100)}…</p>
      )}

      <div className={styles.foot}>
        {isLeaf ? (
          <span className={styles.count}>{node.blocks?.length ?? 0} bloques</span>
        ) : (
          <span className={styles.count}>{childCount} {childCount === 1 ? 'sección' : 'secciones'}</span>
        )}
        <span className={styles.arrow}>{isLeaf ? '⟶' : '→'}</span>
      </div>
    </div>
  );
}
