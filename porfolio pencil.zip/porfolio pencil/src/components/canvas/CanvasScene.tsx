import { useMemo, useEffect } from 'react';
import { CanvasLevelContext } from '../../contexts/CanvasLevelContext';
import { getLevelLayout } from '../../data/canvasLayout';
import { nodeToCamera } from '../../core/canvas-physics';
import { useNavStore } from '../../store/nav.store';
import { useCanvasStore } from '../../store/canvas.store';
import Viewport from './Viewport';
import TourControls from '../ui/TourControls';
import HUD from '../ui/HUD';

export default function CanvasScene() {
  const { currentNode, path } = useNavStore();
  const setCamera = useCanvasStore((s) => s.setCamera);

  const levelId = path.length === 0 ? 'root' : currentNode.id;
  const children = currentNode.children ?? [];

  // Build layout for this level
  const { nodes, connections } = useMemo(() => {
    const childIds = children.map((c) => c.id);
    const layout = getLevelLayout(levelId, childIds);

    const nodes = children
      .map((node) => {
        const pos = layout.positions[node.id];
        return pos ? { node, pos } : null;
      })
      .filter(Boolean) as { node: typeof children[0]; pos: ReturnType<typeof getLevelLayout>['positions'][string] }[];

    return { nodes, connections: layout.connections };
  }, [levelId, children]);

  // Compute initial camera: center on the bounding box of all nodes
  const { initialCx, initialCy, initialScale } = useMemo(() => {
    if (!nodes.length) return { initialCx: 1200, initialCy: 580, initialScale: 0.72 };

    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const { pos } of nodes) {
      minX = Math.min(minX, pos.x);
      maxX = Math.max(maxX, pos.x + pos.width);
      minY = Math.min(minY, pos.y);
      maxY = Math.max(maxY, pos.y + pos.height);
    }

    const cx = (minX + maxX) / 2;
    const cy = (minY + maxY) / 2;
    const w = maxX - minX + 400;
    const h = maxY - minY + 300;
    const scaleX = window.innerWidth / w;
    const scaleY = window.innerHeight / h;
    const scale = Math.min(Math.max(Math.min(scaleX, scaleY) * 0.9, 0.40), 0.90);

    return { initialCx: cx, initialCy: cy, initialScale: scale };
  }, [nodes]);

  // Reset camera every time the level changes
  useEffect(() => {
    const { x, y } = nodeToCamera(initialCx, initialCy, initialScale, window.innerWidth, window.innerHeight);
    setCamera(x, y, initialScale);
  }, [levelId, initialCx, initialCy, initialScale, setCamera]);

  return (
    <CanvasLevelContext.Provider value={{ levelId, nodes, connections, initialCx, initialCy, initialScale }}>
      <Viewport />
      <TourControls />
      <HUD />
    </CanvasLevelContext.Provider>
  );
}
