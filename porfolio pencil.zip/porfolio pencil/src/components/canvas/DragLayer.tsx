import { useCanvasStore } from '../../store/canvas.store';
import ZoomLayer from './ZoomLayer';
import styles from './DragLayer.module.css';

export default function DragLayer() {
  const { x, y, isDragging } = useCanvasStore();

  return (
    <div
      className={styles.drag}
      style={{
        transform: `translate3d(${x}px, ${y}px, 0)`,
        transition: isDragging ? 'none' : 'transform var(--transition-camera)',
        willChange: 'transform',
      }}
    >
      <ZoomLayer />
    </div>
  );
}
