import { useContext } from 'react';
import { useCanvasStore } from '../../store/canvas.store';
import { CanvasLevelContext } from '../../contexts/CanvasLevelContext';
import CanvasGrid from './CanvasGrid';
import CanvasDecorations from './CanvasDecorations';
import CanvasConnections from './CanvasConnections';
import CanvasNode from './CanvasNode';
import styles from './ZoomLayer.module.css';

export default function ZoomLayer() {
  const scale = useCanvasStore((s) => s.scale);
  const { nodes } = useContext(CanvasLevelContext);

  return (
    <div
      className={styles.zoom}
      style={{
        transform: `scale(${scale})`,
        transformOrigin: '0 0',
        willChange: 'transform',
      }}
    >
      <CanvasGrid />
      <CanvasDecorations />
      <CanvasConnections />
      {nodes.map(({ node, pos }) => (
        <CanvasNode key={node.id} node={node} pos={pos} />
      ))}
    </div>
  );
}
