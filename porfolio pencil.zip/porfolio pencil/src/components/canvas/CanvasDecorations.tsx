import styles from './CanvasDecorations.module.css';

// Floating annotations, tech labels, geometric elements
const ANNOTATIONS = [
  { x: 280, y: 200, text: '// software systems', rotate: -8 },
  { x: 1780, y: 160, text: 'integration layer', rotate: 6 },
  { x: 2520, y: 420, text: '> enterprise', rotate: -4 },
  { x: 380, y: 680, text: 'clean architecture', rotate: 5 },
  { x: 2620, y: 700, text: '.NET 8 · C#', rotate: -6 },
  { x: 800, y: 1350, text: 'domain driven', rotate: 8 },
  { x: 1800, y: 1380, text: 'async · real-time', rotate: -5 },
  { x: 2440, y: 1280, text: '700+ commits ↑', rotate: 4 },
  { x: 500, y: 1780, text: '// why > what', rotate: -7 },
  { x: 1700, y: 1820, text: 'business logic', rotate: 6 },
  { x: 1650, y: 2280, text: 'fcastro.info →', rotate: -3 },
];

const CROSSHAIRS = [
  { x: 1020, y: 560 },
  { x: 1860, y: 640 },
  { x: 680, y: 1200 },
  { x: 2360, y: 1100 },
  { x: 1400, y: 1700 },
  { x: 800, y: 2100 },
];

const BRACKETS = [
  { x: 240, y: 490, size: 28 },
  { x: 2700, y: 920, size: 22 },
  { x: 480, y: 1550, size: 24 },
  { x: 1900, y: 2000, size: 26 },
];

const RINGS = [
  { x: 1650, y: 440, r: 36 },
  { x: 2780, y: 260, r: 24 },
  { x: 360, y: 1100, r: 18 },
  { x: 2200, y: 1580, r: 30 },
  { x: 900, y: 2180, r: 22 },
];

export default function CanvasDecorations() {
  return (
    <div className={styles.root} aria-hidden>
      {/* Floating text annotations */}
      {ANNOTATIONS.map((a, i) => (
        <span
          key={i}
          className={styles.annotation}
          style={{
            left: a.x,
            top: a.y,
            transform: `rotate(${a.rotate}deg)`,
          }}
        >
          {a.text}
        </span>
      ))}

      {/* SVG layer: crosshairs, rings, brackets */}
      <svg className={styles.svg} xmlns="http://www.w3.org/2000/svg">
        {CROSSHAIRS.map((c, i) => (
          <g key={i}>
            <line x1={c.x - 12} y1={c.y} x2={c.x + 12} y2={c.y} className={styles.crossLine} />
            <line x1={c.x} y1={c.y - 12} x2={c.x} y2={c.y + 12} className={styles.crossLine} />
            <circle cx={c.x} cy={c.y} r={3} className={styles.crossDot} />
          </g>
        ))}

        {RINGS.map((r, i) => (
          <circle key={i} cx={r.x} cy={r.y} r={r.r} className={styles.ring} />
        ))}

        {BRACKETS.map((b, i) => {
          const { x, y, size: s } = b;
          const h = s * 1.4;
          return (
            <g key={i} className={styles.bracket}>
              {/* Left bracket [ */}
              <path d={`M${x + 8} ${y} L${x} ${y} L${x} ${y + h} L${x + 8} ${y + h}`} />
              {/* Right bracket ] */}
              <path d={`M${x + s - 8} ${y} L${x + s} ${y} L${x + s} ${y + h} L${x + s - 8} ${y + h}`} />
            </g>
          );
        })}
      </svg>
    </div>
  );
}
