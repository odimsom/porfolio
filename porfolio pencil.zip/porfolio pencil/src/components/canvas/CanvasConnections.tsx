import { useContext } from 'react';
import { CanvasLevelContext } from '../../contexts/CanvasLevelContext';
import styles from './CanvasConnections.module.css';

export default function CanvasConnections() {
  const { nodes, connections } = useContext(CanvasLevelContext);

  const posMap = Object.fromEntries(
    nodes.map(({ node, pos }) => [
      node.id,
      { x: pos.x + pos.width / 2, y: pos.y + pos.height / 2 },
    ])
  );

  return (
    <svg className={styles.svg} xmlns="http://www.w3.org/2000/svg" aria-hidden>
      <defs>
        <linearGradient id="thread-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--color-border-hover)" stopOpacity="0.9" />
          <stop offset="100%" stopColor="var(--color-border)" stopOpacity="0.3" />
        </linearGradient>
      </defs>

      {connections.map(([fromId, toId]) => {
        const a = posMap[fromId];
        const b = posMap[toId];
        if (!a || !b) return null;
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const perp = 0.15;
        const cx1 = a.x + dx * 0.4 - dy * perp;
        const cy1 = a.y + dy * 0.4 + dx * perp;
        const cx2 = b.x - dx * 0.4 - dy * perp;
        const cy2 = b.y - dy * 0.4 + dx * perp;

        return (
          <path
            key={`${fromId}-${toId}`}
            d={`M ${a.x} ${a.y} C ${cx1} ${cy1}, ${cx2} ${cy2}, ${b.x} ${b.y}`}
            className={styles.thread}
          />
        );
      })}

      {/* Anchor dot at each node center */}
      {nodes.map(({ node, pos }) => (
        <circle
          key={node.id}
          cx={pos.x + pos.width / 2}
          cy={pos.y + pos.height / 2}
          r={4}
          className={styles.dot}
        />
      ))}
    </svg>
  );
}
