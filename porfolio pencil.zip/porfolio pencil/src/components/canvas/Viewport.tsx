import { useRef, useCallback, useEffect } from 'react';
import { useCanvasStore } from '../../store/canvas.store';
import { applyWheelZoom, clampPosition, computeBounds } from '../../core/canvas-physics';
import DragLayer from './DragLayer';
import styles from './Viewport.module.css';

export default function Viewport() {
  const { x, y, scale, tourStatus, setPosition, setCamera, setDragging } = useCanvasStore();

  const drag = useRef({ active: false, startX: 0, startY: 0, originX: 0, originY: 0 });
  const pinch = useRef({ active: false, dist: 0 });

  const isLocked = tourStatus === 'playing';

  const onPointerDown = useCallback((e: React.PointerEvent) => {
    if (isLocked) return;
    if ((e.target as HTMLElement).closest('[data-node]')) return;
    drag.current = { active: true, startX: e.clientX, startY: e.clientY, originX: x, originY: y };
    setDragging(true);
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  }, [isLocked, x, y, setDragging]);

  const onPointerMove = useCallback((e: React.PointerEvent) => {
    if (!drag.current.active) return;
    const dx = e.clientX - drag.current.startX;
    const dy = e.clientY - drag.current.startY;
    const newX = drag.current.originX + dx;
    const newY = drag.current.originY + dy;
    const bounds = computeBounds(scale, window.innerWidth, window.innerHeight);
    const clamped = clampPosition(newX, newY, bounds);
    setPosition(clamped.x, clamped.y);
  }, [scale, setPosition]);

  const onPointerUp = useCallback(() => {
    drag.current.active = false;
    setDragging(false);
  }, [setDragging]);

  const onWheel = useCallback((e: WheelEvent) => {
    e.preventDefault();
    const state = useCanvasStore.getState();
    const next = applyWheelZoom(e, { x: state.x, y: state.y, scale: state.scale });
    const bounds = computeBounds(next.scale, window.innerWidth, window.innerHeight);
    const clamped = clampPosition(next.x, next.y, bounds);
    setCamera(clamped.x, clamped.y, next.scale);
  }, [setCamera]);

  // Touch pinch-zoom
  const onTouchStart = useCallback((e: TouchEvent) => {
    if (e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      pinch.current = { active: true, dist: Math.hypot(dx, dy) };
    }
  }, []);

  const onTouchMove = useCallback((e: TouchEvent) => {
    if (!pinch.current.active || e.touches.length !== 2) return;
    e.preventDefault();
    const dx = e.touches[0].clientX - e.touches[1].clientX;
    const dy = e.touches[0].clientY - e.touches[1].clientY;
    const newDist = Math.hypot(dx, dy);
    const ratio = newDist / pinch.current.dist;
    pinch.current.dist = newDist;
    const state = useCanvasStore.getState();
    const focal = {
      x: (e.touches[0].clientX + e.touches[1].clientX) / 2,
      y: (e.touches[0].clientY + e.touches[1].clientY) / 2,
    };
    const nextScale = state.scale * ratio;
    const bounds = computeBounds(nextScale, window.innerWidth, window.innerHeight);
    const clamped = clampPosition(
      focal.x - (focal.x - state.x) * ratio,
      focal.y - (focal.y - state.y) * ratio,
      bounds
    );
    setCamera(clamped.x, clamped.y, nextScale);
  }, [setCamera]);

  const viewportRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = viewportRef.current;
    if (!el) return;
    el.addEventListener('wheel', onWheel, { passive: false });
    el.addEventListener('touchstart', onTouchStart, { passive: true });
    el.addEventListener('touchmove', onTouchMove, { passive: false });
    return () => {
      el.removeEventListener('wheel', onWheel);
      el.removeEventListener('touchstart', onTouchStart);
      el.removeEventListener('touchmove', onTouchMove);
    };
  }, [onWheel, onTouchStart, onTouchMove]);

  return (
    <div
      ref={viewportRef}
      className={styles.viewport}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerLeave={onPointerUp}
      style={{ cursor: isLocked ? 'default' : drag.current.active ? 'grabbing' : 'grab' }}
    >
      <DragLayer />
    </div>
  );
}
