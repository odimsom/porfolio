import { createContext } from 'react';
import type { TreeNode } from '../data/tree';
import type { CanvasPosition } from '../data/canvasLayout';

export interface LevelNode {
  node: TreeNode;
  pos: CanvasPosition;
}

export interface CanvasLevelCtx {
  levelId: string;                           // id of the parent node (or 'root')
  nodes: LevelNode[];                        // children at this level
  connections: [string, string][];           // narrative connections between node ids
  initialCx: number;                         // camera target center x
  initialCy: number;                         // camera target center y
  initialScale: number;
}

export const CanvasLevelContext = createContext<CanvasLevelCtx>({
  levelId: 'root',
  nodes: [],
  connections: [],
  initialCx: 1200,
  initialCy: 580,
  initialScale: 0.72,
});
