import gsap from 'gsap';
import { nodeToCamera } from './canvas-physics';

export interface PortfolioNode {
  id: string;
  x: number;   // canvas center x
  y: number;   // canvas center y
}

export type TourStatus = 'idle' | 'playing' | 'paused';

interface TourOptions {
  nodes: PortfolioNode[];
  getCamera: () => { x: number; y: number; scale: number };
  getVW: () => number;
  getVH: () => number;
  setCamera: (x: number, y: number, scale: number) => void;
  setFocusedNode: (id: string | null) => void;
  setTourStatus: (s: TourStatus) => void;
  stepDuration: number;
  travelDuration: number;
}

export class TourEngine {
  private opts: TourOptions;
  private stepIndex = 0;
  private tween: gsap.core.Tween | null = null;
  private stepTimer: ReturnType<typeof setTimeout> | null = null;
  private stateRef = { x: 0, y: 0, scale: 1 };

  constructor(opts: TourOptions) {
    this.opts = opts;
  }

  play() {
    this.opts.setTourStatus('playing');
    this.runStep(this.stepIndex);
  }

  pause() {
    this.opts.setTourStatus('paused');
    this.tween?.pause();
    if (this.stepTimer) clearTimeout(this.stepTimer);
  }

  resume() {
    this.opts.setTourStatus('playing');
    if (this.tween?.paused()) this.tween.resume();
    else this.runStep(this.stepIndex);
  }

  stop() {
    this.kill();
    this.stepIndex = 0;
    this.opts.setTourStatus('idle');
    this.opts.setFocusedNode(null);
  }

  interrupt() {
    this.kill();
    this.opts.setTourStatus('idle');
    this.opts.setFocusedNode(null);
  }

  private kill() {
    this.tween?.kill();
    if (this.stepTimer) clearTimeout(this.stepTimer);
  }

  private runStep(index: number) {
    const { nodes, getCamera, getVW, getVH, setCamera, setFocusedNode, stepDuration, travelDuration } = this.opts;

    if (index >= nodes.length) { this.stop(); return; }

    const node = nodes[index];
    const targetScale = 1.05;
    const { x: tx, y: ty } = nodeToCamera(node.x, node.y, targetScale, getVW(), getVH());

    // Always start from actual current camera position
    const cam = getCamera();
    this.stateRef = { x: cam.x, y: cam.y, scale: cam.scale };

    this.tween = gsap.to(this.stateRef, {
      x: tx, y: ty, scale: targetScale,
      duration: travelDuration,
      ease: 'power3.inOut',
      onUpdate: () => setCamera(this.stateRef.x, this.stateRef.y, this.stateRef.scale),
      onComplete: () => {
        setFocusedNode(node.id);
        this.stepTimer = setTimeout(() => {
          setFocusedNode(null);
          const pullRef = { scale: this.stateRef.scale };
          gsap.to(pullRef, {
            scale: targetScale * 0.88,
            duration: 0.4,
            ease: 'power2.in',
            onUpdate: () => setCamera(this.stateRef.x, this.stateRef.y, pullRef.scale),
            onComplete: () => {
              this.stateRef.scale = pullRef.scale;
              this.stepIndex = index + 1;
              this.runStep(this.stepIndex);
            },
          });
        }, stepDuration * 1000);
      },
    });
  }
}
