export interface CanvasState {
  x: number;
  y: number;
  scale: number;
}

export interface CanvasBounds {
  minX: number; maxX: number;
  minY: number; maxY: number;
}

const CANVAS_W = 4000;
const CANVAS_H = 3000;

export function computeBounds(scale: number, vw: number, vh: number): CanvasBounds {
  const w = CANVAS_W * scale;
  const h = CANVAS_H * scale;
  const maxX = vw * 0.3;
  const maxY = vh * 0.3;
  return {
    minX: -(w - vw) - maxX,
    maxX,
    minY: -(h - vh) - maxY,
    maxY,
  };
}

export function clampPosition(x: number, y: number, bounds: CanvasBounds) {
  return {
    x: Math.min(bounds.maxX, Math.max(bounds.minX, x)),
    y: Math.min(bounds.maxY, Math.max(bounds.minY, y)),
  };
}

export function clampScale(scale: number): number {
  return Math.min(2.0, Math.max(0.25, scale));
}

/** Convert node canvas coords to screen-center offset for camera targeting */
export function nodeToCamera(
  nodeX: number, nodeY: number,
  scale: number,
  vw: number, vh: number
): { x: number; y: number } {
  return {
    x: vw / 2 - nodeX * scale,
    y: vh / 2 - nodeY * scale,
  };
}

/** Pinch-zoom math: returns new scale and adjusted position to zoom around a focal point */
export function applyPinchZoom(
  prevScale: number, nextScale: number,
  focalX: number, focalY: number,
  currentX: number, currentY: number
): CanvasState {
  const clamped = clampScale(nextScale);
  const ratio = clamped / prevScale;
  return {
    scale: clamped,
    x: focalX - (focalX - currentX) * ratio,
    y: focalY - (focalY - currentY) * ratio,
  };
}

/** Wheel zoom math */
export function applyWheelZoom(
  event: WheelEvent,
  current: CanvasState
): CanvasState {
  const delta = -event.deltaY * 0.001;
  const nextScale = clampScale(current.scale * (1 + delta));
  return applyPinchZoom(current.scale, nextScale, event.clientX, event.clientY, current.x, current.y);
}
