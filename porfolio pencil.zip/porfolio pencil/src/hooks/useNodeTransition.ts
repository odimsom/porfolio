import { useCallback, RefObject } from 'react';
import gsap from 'gsap';
import { useNavStore } from '../store/nav.store';
import { useCanvasStore } from '../store/canvas.store';
import { getLevelLayout } from '../data/canvasLayout';
import { nodeToCamera } from '../core/canvas-physics';
import type { TreeNode } from '../data/tree';

export function useNodeTransition(overlayRef: RefObject<HTMLDivElement | null>) {
  const { push, pop, setTransitioning } = useNavStore();
  const { pushCamera } = useCanvasStore();

  const enter = useCallback(
    (node: TreeNode, cardEl: HTMLElement) => {
      if (!overlayRef.current) return;
      setTransitioning(true);

      const rect = cardEl.getBoundingClientRect();
      const overlay = overlayRef.current;

      // Compute the initial camera for the level we're entering
      const childIds = (node.children ?? []).map((c) => c.id);
      const layout = getLevelLayout(node.id, childIds);
      const positions = Object.values(layout.positions);

      let nextCx = 1000, nextCy = 500, nextScale = 0.75;
      if (positions.length) {
        let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
        for (const p of positions) {
          minX = Math.min(minX, p.x);
          maxX = Math.max(maxX, p.x + p.width);
          minY = Math.min(minY, p.y);
          maxY = Math.max(maxY, p.y + p.height);
        }
        nextCx = (minX + maxX) / 2;
        nextCy = (minY + maxY) / 2;
        const w = maxX - minX + 400;
        const h = maxY - minY + 300;
        const sx = window.innerWidth / w;
        const sy = window.innerHeight / h;
        nextScale = Math.min(Math.max(Math.min(sx, sy) * 0.9, 0.40), 0.90);
      }

      // Seed overlay at card's position
      gsap.set(overlay, {
        display: 'block',
        position: 'fixed',
        left: rect.left,
        top: rect.top,
        width: rect.width,
        height: rect.height,
        borderRadius: 20,
        opacity: 1,
        zIndex: 50,
      });

      // Fade out sibling cards
      gsap.to('[data-card]', {
        opacity: 0,
        scale: 0.94,
        duration: 0.22,
        ease: 'power2.in',
        stagger: 0.025,
      });

      // Bloom to fullscreen
      gsap.to(overlay, {
        left: 0, top: 0,
        width: '100vw', height: '100vh',
        borderRadius: 0,
        duration: 0.5,
        ease: 'power3.inOut',
        delay: 0.08,
        onComplete: () => {
          // Save old camera, jump to new level's camera
          const { x: nx, y: ny } = nodeToCamera(nextCx, nextCy, nextScale, window.innerWidth, window.innerHeight);
          pushCamera(nx, ny, nextScale);
          push(node.id);

          gsap.to(overlay, {
            opacity: 0,
            duration: 0.18,
            onComplete: () => {
              gsap.set(overlay, { display: 'none' });
              setTransitioning(false);

              gsap.fromTo(
                '[data-card]',
                { opacity: 0, y: 18, scale: 0.96 },
                { opacity: 1, y: 0, scale: 1, duration: 0.32, stagger: 0.07, ease: 'power2.out' }
              );
            },
          });
        },
      });
    },
    [overlayRef, push, pushCamera, setTransitioning]
  );

  const back = useCallback(() => {
    setTransitioning(true);

    gsap.to('[data-card]', {
      opacity: 0,
      y: -12,
      scale: 0.96,
      duration: 0.2,
      ease: 'power2.in',
      stagger: 0.03,
      onComplete: () => {
        pop();
        setTransitioning(false);

        gsap.fromTo(
          '[data-card]',
          { opacity: 0, y: 20, scale: 0.97 },
          { opacity: 1, y: 0, scale: 1, duration: 0.3, stagger: 0.07, ease: 'power2.out' }
        );
      },
    });
  }, [pop, setTransitioning]);

  return { enter, back };
}
